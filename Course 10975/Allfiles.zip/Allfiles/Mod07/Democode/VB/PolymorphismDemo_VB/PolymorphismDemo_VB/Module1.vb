﻿Imports System.IO
Module Module1

    Sub Main()
        Dim x As Integer
        File.ReadAllText("c:\test.txt")
        System.Console.Read()
    End Sub

End Module
