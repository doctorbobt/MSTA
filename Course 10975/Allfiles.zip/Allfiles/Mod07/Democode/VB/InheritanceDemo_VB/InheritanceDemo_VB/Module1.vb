﻿Module Module1

    Sub Main()

        Dim newStudent As New Student()
        newStudent.Age = 21
        newStudent.eat()

        Dim newInstructor As New Instructor()
        newInstructor.Height = 5.9F
        newInstructor.move()


    End Sub

End Module
