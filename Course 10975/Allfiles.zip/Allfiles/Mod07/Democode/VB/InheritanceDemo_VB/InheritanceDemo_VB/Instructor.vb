﻿Public Class Instructor
    Inherits Person

End Class
