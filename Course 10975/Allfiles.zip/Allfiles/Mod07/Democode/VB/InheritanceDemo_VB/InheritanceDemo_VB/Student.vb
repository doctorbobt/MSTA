﻿Public Class Student
    Inherits Person


End Class
