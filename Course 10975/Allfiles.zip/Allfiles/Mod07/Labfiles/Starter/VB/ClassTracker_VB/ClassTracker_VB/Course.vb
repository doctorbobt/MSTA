﻿Public Class Course

End Class
