﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Value_Reference_Demo_CS
{
    class Point
    {
        int x;
        int y;
    }
}
