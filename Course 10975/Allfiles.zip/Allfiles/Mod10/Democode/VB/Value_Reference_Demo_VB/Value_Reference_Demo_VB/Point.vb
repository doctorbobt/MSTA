﻿Public Class Point
    Dim x As Integer
    Dim y As Integer
End Class
