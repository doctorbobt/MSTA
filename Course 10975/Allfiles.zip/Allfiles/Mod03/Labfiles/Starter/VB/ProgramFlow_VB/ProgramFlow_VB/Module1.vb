﻿Module Module1

    Sub Main()


    End Sub


    Sub CalculateAverage()

        Dim grades = New Double() {89, 98, 99, 90, 95}
        
    End Sub

End Module
