﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmDataStructures_CS
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create an array here called grdsArray

            


            // Call the addGrades method, passing it the grdsArray




            // After adding grades to the array, call the displayGrades method
            // to print out the grades to the console window
            // Use the foreach construct to iterate over the array




            // Create a new Stack object called myStack




            // Call the pushStack() method passing in the grades array for values




            // Call the popStack() method twice to remove the top two items from stack
            // The popStack method will display each popped item to the console window




            // Create a new SortedList object called myCourses




            // Call the populateList() method




            // display a course in the list by passing a key




            // Remove an item from the myCourses list using the key

        }


        static void addGrades(float[] grdArray)
        {
            
        }

        static void displayGrades(float[] grdArray)
        {
            
        }


        static void pushStack(float[] grdArray)
        {

        }

        static void popStack(Stack stack)
        {
            Console.WriteLine("Item removed from the stack: ");

        }

        static void populateList(SortedList list)
        {

        }

        static void displayList(SortedList list, string key)
        {

        }

        static void removeListItem(SortedList list, string key)
        {

        }
    }
}
