﻿using System;
using System.Data.SqlClient;

namespace DbExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string cs = "Put you connection string here";
            SqlConnection myConn = new SqlConnection(cs);

            AddStudent(myConn);

            ShowData(myConn);

            Console.Read();
        }

        private static void AddStudent(SqlConnection myConn)
        {
            Console.Write("Id: ");
            string id = Console.ReadLine();
            Console.Write("First Name: ");
            string fn = Console.ReadLine();
            Console.Write("Last Name: ");
            string ln = Console.ReadLine();
            Console.Write("Age: ");
            string age = Console.ReadLine();
            string values = String.Format("{0}, '{1}', '{2}', {3}", id, fn, ln, age);


            SqlCommand myCommand = myConn.CreateCommand();
            myCommand.CommandText = "INSERT INTO dbo.Students (Id, FirstName, LastName, Age) VALUES ("+values+")";
            myConn.Open();
            myCommand.ExecuteNonQuery();
            myConn.Close();
        }

        private static void ShowData(SqlConnection myConn)
        {
            SqlCommand myCommand = myConn.CreateCommand();
            myCommand.CommandText = "SELECT * FROM dbo.Students";
            myConn.Open();
            SqlDataReader myReader = myCommand.ExecuteReader();

            while (myReader.Read())
            {
                string dbData = String.Format("{0}, {1}, {2}, {3}", myReader[0], myReader[1], myReader[2], myReader[3]);
                Console.WriteLine(dbData);
            }
        }
    }
}
