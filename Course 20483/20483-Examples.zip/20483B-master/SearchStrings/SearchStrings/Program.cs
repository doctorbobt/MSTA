﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SearchStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            string value = "Brave new world";
            int indexOf = value.IndexOf('w'); // returns 8
            int lastIndexOf = value.LastIndexOf('w'); // returns 10

            string value2 = "< mycustominput >";
            if (value2.StartsWith("<"))
            {

            }

            if (value2.EndsWith(">"))
            {
            }

            string value3 = "My Sample Value";
            string subString = value3.Substring(3, 6); // Returns ‘Sample’

            // The @ makes sure that I don't need to escape the \ character with another \
            string pattern = @"(Mr\.\s|Ms\.\s)"; // The \. matches the punctuation mark (.), \s matches a single whitespace character
            string[] names = { "Mr. Henry Hunt", "Ms. Sara Samuels", "Abraham Adams", "Ms. Nicole Norris" };

            foreach (string name in names)
                Console.WriteLine(Regex.Replace(name, pattern, String.Empty));

            // A string is an array of characters. You can enumerate a string just as if it were a typical collection.
            string value4 = "My Custom Value";
            foreach (char c in value4)
                Console.WriteLine(c);

            Console.ReadKey();
        }
    }
}
