﻿#define CONDITION1 // this will allow MyMethod to run

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CreateAttributes
{
    class Program
    {
        static void Main(string[] args)
        {

            Type clsType = typeof(Program);
            // Get the MethodInfo object for Method1.
            MethodInfo mInfo = clsType.GetMethod("MyMethod");

            // retrieve the specific instance of an attribute so that you can look at its properties
            ConditionalAttribute conditionalAttribute =
            (ConditionalAttribute)Attribute.GetCustomAttribute(mInfo, typeof(ConditionalAttribute));
            Console.WriteLine(conditionalAttribute.ConditionString); // returns CONDITION11. Remove Conditional("CONDITION2") first, otherwise AmbiguousMatchException.
            
            ConditionalMethod();
            DebugMethod();


            // Seeing whether MyCustomAttribute is defined for MyTestClass
            if (Attribute.IsDefined(typeof(MyTestClass), typeof(MyCustomAttribute)))
            {
                Console.WriteLine("MyCustomAttribute has been applied to MyTestClass");
                Console.ReadKey();
            }
        }

        // Note: ConditionalAttribute only works on void methods
        [Conditional("CONDITION1"), Conditional("CONDITION2")]
        public static void ConditionalMethod()
        {
            Console.WriteLine("Use the ConditionalAttribute to indicate to the compiler that a method call should will be ignored unless a specific compiler option is specified (CONDITION1 or CONDITION2 or both)");
        }

        // Will only run in debug mode
        [Conditional("DEBUG")]
        public static void DebugMethod()
        {
            Console.WriteLine("Debug info");
        }


    }

    // When using the custom attribute, you reference it by the name and exclude the Attribute part
    [MyCustom("lala", Property1 = true, Property2 = "Hello World", Property3 = MyCustomAttribute.MyCustomAttributeEnum.Red)]
    class MyTestClass
    {

    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)] // limit the scope of this attribute so that the target can be only a class or struct
    class MyCustomAttribute : Attribute 
    {
        public string ConstructorDescription { get; set; }
        public MyCustomAttribute(string constructorDescription)
        {
            ConstructorDescription = constructorDescription;
        }

        public enum MyCustomAttributeEnum
        {
            Red,
            White,
            Blue
        }
        public bool Property1 { get; set; }
        public string Property2 { get; set; }
        public MyCustomAttributeEnum Property3 { get; set; }
    }
}
