﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoggingAndTracing
{
    class Program
    {
        static void Main(string[] args)
        {
            // Tracing:
            // Using the Debug class
            Debug.WriteLine("Starting application");
            Debug.Indent();
            int i = 1 + 2;
            Debug.Assert(i == 3); // indicate a bug in your code that you want pointed out to you while developing your application. Gives error if fails. 
            Debug.WriteLineIf(i > 0, "i is greater than 0");
            Debug.Unindent();

            // Using the TraceSource class (should be used instead of the static Trace class)
            TraceSource traceSource = new TraceSource("myTraceSource", SourceLevels.All); // allows all events through
            traceSource.TraceInformation("Tracing application..");
            traceSource.TraceEvent(TraceEventType.Critical, 0,"Critical trace"); // Writes a trace event message
            traceSource.TraceData(TraceEventType.Information, 1, new object[] { "a", "b", "c" }); // writes trace data
            traceSource.Flush();
            traceSource.Close();
            
            // Outputs:
            // myTraceSource Information: 0 : Tracing application..
            // myTraceSource Critical: 0 : Critical trace
            // myTraceSource Information: 1 : a, b, c

            // Logging:
            // Writing data to the event log
            /* if (!EventLog.SourceExists("MySource"))
            {
                EventLog.CreateEventSource("MySource","MyNewLog");
                Console.WriteLine("Created Event Source");
            }
            EventLog myLog = new EventLog();
            myLog.Source ="MySource";
            myLog.WriteEntry("Houston, we have a problem");
            */

            // Reading data from the event log
            EventLog log = new EventLog("MyNewLog");
            Console.WriteLine("Totalentries: " + log.Entries.Count);
            EventLogEntry last = log.Entries[log.Entries.Count - 1];
            Console.WriteLine("Index:" + last.Index);
            Console.WriteLine("Source:" + last.Source);
            Console.WriteLine("Type:" + last.EntryType);
            Console.WriteLine("Time:" + last.TimeWritten);
            Console.WriteLine("Message:" + last.Message);

            Console.ReadKey();
        }
    }
}
