﻿using System;
using System.IO;

namespace UnmanagedResources
{
    class Program
    {
        private static int ObjectNumber = 1;
        static void Main(string[] args)
        {
            Console.WriteLine("Enter input:"); 
            string line = Console.ReadLine(); 

            while (line != "exit")
            {
                if (line == "CreateDispose")
                {
                    // Make an object.
                    DisposableClass obj = new DisposableClass();
                    obj.Name = "CreateAndDispose " + ObjectNumber.ToString();
                    ObjectNumber++;
                    // Dispose of the object.
                    obj.Dispose();

                    /* as a using statement (is more safe, because it automatically uses try/finally):
                      using (DisposableClass obj = new DisposableClass())
                       {
                        obj.Name = "CreateAndDispose " + ObjectNumber.ToString();
                        ObjectNumber++;
                       } */
                }
                else if (line == "Create")
                {
                    // Make an object.
                    DisposableClass obj = new DisposableClass();
                    obj.Name = "Create " + ObjectNumber.ToString();
                    ObjectNumber++;
                }
                else if (line == "CollectGarbage")
                {
                    GC.Collect();
                }
                Console.WriteLine("Enter input:");
                line = Console.ReadLine();
            }
        }
    }

    class DisposableClass : IDisposable
    {
        // A name to keep track of the object.
        public string Name = "";

        // If Dispose is called explicitly; free managed (=true) and unmanaged resources.
        public void Dispose()
        {
            FreeResources(true);
        }

        // If the finalizer calls Dispose, then use this Destructor to clean up unmanaged resources but not managed resources (they may have already've been destroyed)
        ~DisposableClass()
        {
            FreeResources(false);
        }


        // Keep track if whether resources are already freed.
        private bool ResourcesAreFreed = false;
        // Free resources.
        private void FreeResources(bool freeManagedResources)
        {
            Console.WriteLine(Name + ": FreeResources");
            if (!ResourcesAreFreed)
            {
                // Dispose of managed resources if appropriate.
                if (freeManagedResources)
                {
                    // Dispose of managed resources here.
                    Console.WriteLine(Name + ": Dispose of managed resources");
                }
                // Dispose of unmanaged resources here.
                Console.WriteLine(Name + ": Dispose of unmanaged resources");
                // Remember that we have disposed of resources.
                ResourcesAreFreed = true;
                // We don't need the destructor because our resources are already freed.
                GC.SuppressFinalize(this);
            }
        }
    }
}
 