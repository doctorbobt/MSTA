﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace ImplementIEnumerable
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Arnold", "Schwarzenegger");
            Person person2 = new Person("Sylvester", "Stallone");
            Person person3 = new Person("Bruce", "Lee");

            Person[] listofActors = new Person[3] { person1, person2, person3 };

            People people = new People(listofActors);

            // he foreach statement in C# is some nice syntactic sugar that hides from you that you are
            // using the GetEnumerator and MoveNext methods.
            foreach (Person person in people)
            {
                Console.WriteLine(person.ToString());
            }
            Console.ReadKey();
        }
    }

    class Person
    {
        public Person(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public override string ToString()
        {
            return FirstName + " " + LastName;
        }
    }
    class People : IEnumerable<Person>
    {
        public People(Person[] people)
        {
            this.people = people;
        }

        Person[] people;
        public IEnumerator<Person> GetEnumerator()
        {
            for (int index = 0; index < people.Length; index++)
            {
                yield return people[index]; // instructs the compiler to convert this regular code to a state machine.
            }
        }

        // The IEnumerable interface exposes a GetEnumerator method that returns an enumerator.
        // The enumerator has a MoveNext method that returns the next item in the collection.
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}