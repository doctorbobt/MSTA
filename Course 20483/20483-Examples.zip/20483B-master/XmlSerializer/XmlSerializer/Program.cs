﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace XmlSerializerTest
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Person));
            string xml;

            using (StringWriter stringWriter = new StringWriter())
            {
                Person p = new Person
                {
                    FirstName ="John",
                    LastName ="Doe",
                    Age = 42
                };

                serializer.Serialize(stringWriter, p); // Serializes Person object and writes the XML document to a file using the stringwriter
                xml = stringWriter.ToString(); // Writes the XML to a variable
            }
            Console.WriteLine(xml); // Display the XML


            using (StringReader stringReader = new StringReader(xml))
            {
                Person p = (Person)serializer.Deserialize(stringReader); // Deserializes the XML document contained by the specified stringreader
                Console.WriteLine(p.FirstName + " " + p.LastName + " is " + p.Age + " years old");
            }
            Console.ReadKey();
        }
    }

    [Serializable]
    public class Person
    {
        // Fields need to be public for the XML serializer

        public string FirstName { get; set; }

        [XmlIgnore] // makes sure that an element is not serialized, in this case LastName will be ignored 
        public string LastName { get; set; }
        public int Age { get; set; }

    }
}
