﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovarianceAndContravariance
{
    class Person { }
    class Employee : Person { }

    class Program
    {
        // A delegate that returns a Person.
        //private delegate Person ReturnPersonDelegate();
        //private ReturnPersonDelegate ReturnPersonMethod;

        // now using Func delegate instead of making my own delegate type
        private Func<Person> ReturnPersonMethod;

        // A method that returns an Employee.
        private Employee ReturnEmployee()
        {
            return new Employee();
        }

        // A delegate that takes an Employee as a parameter.
        // private delegate void EmployeeParameterDelegate(Employee employee);
        // private EmployeeParameterDelegate EmployeeParameterMethod;

        // now using Action delegate instead of making my own delegate type
        private Action<Employee> EmployeeParameterMethod;

        // A method that takes a Person as a parameter.
        private void PersonParameter(Person person)
        {

        }

         void Main(string[] args)
        {
            // Use covariance to set ReturnPersonMethod = ReturnEmployee.
            ReturnPersonMethod = ReturnEmployee;
            // Use contravariance to set EmployeeParameterMethod = PersonParameter.
            EmployeeParameterMethod = PersonParameter;

            Console.ReadKey();
        }
    }
}
