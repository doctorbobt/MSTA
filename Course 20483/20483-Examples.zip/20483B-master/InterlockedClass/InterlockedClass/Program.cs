﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace InterlockedClass
{
    // Interlocked guarantees that the increment and decrement operations are executed atomically.
    // No other thread will see any intermediate results.

     
    class Program
    {
        static void Main()
        {
            // adding and subtracting is a simple operation. 
            // If you have more complex operations, you would still have to use a lock.
            int n = 0;
            var up = Task.Run(() =>
            {
                for (int i = 0; i < 1000000; i++)
                    Interlocked.Increment(ref n);
            });

            for (int i = 0; i < 1000000; i++)
                Interlocked.Decrement(ref n);
            up.Wait();
            Console.WriteLine(n);
            Console.ReadKey();

            /*  Does exactly the same, except it uses a lock
             object _lock = new object();

            var up = Task.Run(() =>
            {
                for (int i = 0; i < 1000000; i++)
                    lock (_lock)
                        n++;
            });

            for (int i = 0; i < 1000000; i++)
                lock (_lock)
                    n--;
              */
        }
    }
}
