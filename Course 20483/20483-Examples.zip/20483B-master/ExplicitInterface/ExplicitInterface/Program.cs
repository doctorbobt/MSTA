﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterface
{
    class Program 
    {
        static void Main(string[] args)
        {
            Implementation impl = new Implementation();
            // impl.MyMethod -> Because of explicit interface implementation, you can’t access MyMethod through instance of Implementation

            // But when you (implicitly) cast Implementation to IInterfaceA, you have access to MyMethod.
            IInterfaceA interfaceA = impl;
            interfaceA.MyMethod();
        }
    }

    // Explicit interface implementation can be used to hide members of a class to outside users
    class Implementation : IInterfaceA
    {
        void IInterfaceA.MyMethod()
        {

        }
    }

    interface IInterfaceA
    {
        void MyMethod();
    }

    // Another situation in which explicit interface implementation is necessary: 
    // when a class implements two interfaces that contain duplicate method signatures but wants a different implementation for both.
    // When implicitly implementing those two interfaces, only one method exists in the implementation.
    class MoveableOject : ILeft, IRight
    {
        void ILeft.Move()
        {
        }

        void IRight.Move()
        {
        }
    }

    interface ILeft
    {
        void Move();
    }
    interface IRight
    {
        void Move();
    }
}
