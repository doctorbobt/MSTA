﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Web.Script.Serialization;

namespace JSONSerializer
{
    class Program
    {
        static void Main(string[] args)
        {
            Programmer p = new Programmer
            {
                Id = 1,
                Name = "Richard Cats",
                ProgrammingLanguage = "C#",
                DatabaseSkills = true,
                WebSkills = true
            };

            using (MemoryStream stream = new MemoryStream())
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Programmer));
                ser.WriteObject(stream, p); // Serializes the object (p) to JSON data and writes the resulting JSON to a stream
                stream.Position = 0;
                StreamReader streamReader = new StreamReader(stream); // reads the characters in the stream

                string serializedResult = streamReader.ReadToEnd();
                Console.WriteLine(serializedResult); // Displays: {"Id":1,"Name":"Richard Cats","WebSkills":true,"ProgrammingLanguage":"C#","DatabaseSkills":true}


                // Deserializing JSON input (serializedResult) to Dictionary<string,string>
                // If you pass some invalid JSON to this function, an ArgumentException is thrown
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                Dictionary<string, string> programmers = serializer.Deserialize<Dictionary<string, string>>(serializedResult);

                // loop through the dictionary to see the property names and their values
                Console.WriteLine("Deserialized results:");
                foreach (KeyValuePair<string, string> programmer in programmers)
                {
                    Console.WriteLine(programmer);
                }
            }

            Console.ReadKey();
        }
    }
    [DataContract]
    public class Programmer : Employee
    {
        [DataMember(Order = 1)]
        public bool DatabaseSkills { get; set; }
        [DataMember(Order = 0)]
        public string ProgrammingLanguage { get; set; }
        [DataMember]
        public bool WebSkills { get; set; }

        [OnSerializing()]
        internal void OnSerializingMethod(StreamingContext context)
        {
            Console.WriteLine("Serialize started");
        }

        [OnSerialized()]
        internal void OnSerializedMethod(StreamingContext context)
        {
            Console.WriteLine("Serialize complete");
        }
    }

    [DataContract]
    public class Employee
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Name { get; set; }
    }
}
