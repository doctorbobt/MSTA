﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerformanceCounters
{
    class Program
    {
        static void Main(string[] args)
        {
            // The first time, the application will create two new performance counters.
            if (CreatePerformanceCounters())
            {
                Console.WriteLine("Created performance counters");
                Console.WriteLine("Please restart application");
                Console.ReadKey();
                return;
            }

            // The second time, it will increment both counters by one.
            var totalOperationsCounter = new PerformanceCounter(
                "MyCategory",
                "# operations executed",
                "",
            false);
            var operationsPerSecondCounter = new PerformanceCounter(
                "MyCategory",
                 "# operations / sec",
                 "",
            false);
            totalOperationsCounter.Increment();
            operationsPerSecondCounter.Increment();
        }

        // Show counters in Windows Performance Monitoring tool
        private static bool CreatePerformanceCounters()
        {
            if (!PerformanceCounterCategory.Exists("MyCategory"))
            {
                CounterCreationDataCollection counters =
                    new CounterCreationDataCollection
                {
                    new CounterCreationData(
                        "# operations executed",
                        "Totalnumberofoperationsexecuted",
                         PerformanceCounterType.NumberOfItems32), // used for counting the number of operations or items.
                    new CounterCreationData(
                        "# operations / sec",
                        "Numberofoperationsexecutedpersecond",
                         PerformanceCounterType.RateOfCountsPerSecond32) // used to calculate the amount per second of an item or operation
                };
                PerformanceCounterCategory.Create("MyCategory","Sample category for Codeproject", PerformanceCounterCategoryType.MultiInstance, counters) ;
                return true;
            }
            return false;
        }
    }
}
