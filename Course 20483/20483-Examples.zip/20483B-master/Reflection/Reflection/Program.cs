﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            AssemblyName[] assemblyNames = assembly.GetReferencedAssemblies();
            foreach (AssemblyName assemblyName in assemblyNames)
            {
                Debug.WriteLine("Assembly Name: " + assemblyName.FullName);
                Assembly referencedAssembly = Assembly.Load(assemblyName.FullName);
                object[] attributes = referencedAssembly.GetCustomAttributes(false);
                foreach (object attribute in attributes)
                {
                    Debug.WriteLine("Attribute Name: " + attribute.GetType().Name);
                    //Get the properties of this attribute
                    PropertyInfo[] properties = attribute.GetType().GetProperties();

                    foreach (PropertyInfo property in properties)
                    {
                        Debug.WriteLine(property.Name + " : " + property.GetValue(attribute));
                    }
                }
            }

            // Inspecting an assembly for types that implement a custom interface
            Assembly pluginAssembly = Assembly.Load("Reflection");
            var plugins = from type in pluginAssembly.GetTypes()
                          where typeof(IPlugin).IsAssignableFrom(type) && !type.IsInterface
                          select type;
            foreach (Type pluginType in plugins)
            {
                IPlugin plugin = Activator.CreateInstance(pluginType) as IPlugin;
                Console.WriteLine(plugin); // returns MyPlugin1 and MyPlugin2
            }

            // Getting the value of a field through reflection
            MyPlugin testPlugin = new MyPlugin();
            DumpObject(testPlugin); // Returns 1337

            // Executing a method through reflection
            int i = 42;
            MethodInfo compareToMethod = i.GetType().GetMethod("CompareTo", new Type[] { typeof(int) });
            int result = (int)compareToMethod.Invoke(i, new object[] { 43 });
            Console.WriteLine(result); // returns -1

            Console.ReadKey();
        }

        static void DumpObject(object obj)
        {
            FieldInfo[] fields = obj.GetType().GetFields(BindingFlags.Instance | BindingFlags.
            NonPublic);
            foreach (FieldInfo field in fields)
            {
                if (field.FieldType == typeof(int))
                {
                    Console.WriteLine(field.GetValue(obj));
                }
            }
        }
    }

    public class MyPlugin : IPlugin
    {
        private int secretValue = 1337;
        public string Name
        {
            get { return "MyPlugin"; }
        }
        public string Description
        {
            get { return "My Sample Plugin"; }
        }
    }

    public class MyPlugin2 : IPlugin
    {
        public string Name
        {
            get { return "MyPlugin"; }
        }
        public string Description
        {
            get { return "My Sample Plugin"; }
        }
    }

    public interface IPlugin
    {
        string Name { get; }
        string Description { get; }
    }
}
