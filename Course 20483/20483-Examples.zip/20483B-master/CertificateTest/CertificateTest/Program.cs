﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace CertificateTest
{
    class Program
    {
        // This small program starts by opening in read-only mode the root store from the local machine and
        // then prints the name and the expiration date of all the certificates in there.
        static void Main(string[] args)
        {
            X509Store store = new X509Store(StoreName.Root, StoreLocation.LocalMachine); // Certificate store for trusted root CAs. Represents the certificate store common to all users on the local machine.
            store.Open(OpenFlags.ReadOnly);
            Console.WriteLine("Friendly Name\t\t\t\t\t Expiration date");
            foreach (X509Certificate2 certificate in store.Certificates)
            {
                Console.WriteLine("{0}\t{1}", certificate.FriendlyName
                , certificate.NotAfter);
            }
            store.Close();
            Console.ReadKey();
        }
    }
}
