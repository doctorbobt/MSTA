﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Grades.DataModel
{
    public partial class Grade
    {
        public bool ValidateAssessmentDate(DateTime date)
        {
            if (date > DateTime.Now)
                throw new ArgumentOutOfRangeException();
            else
                return true;
        }

        public bool ValidateAssessmentDate(string date)
        {
            Match matchGrade = Regex.Match(date, @"^[A-E][+-]?$");

            if (!matchGrade.Success)
                throw new ArgumentOutOfRangeException("The date is not valid");
            else
                return true;
        }
    }
}
