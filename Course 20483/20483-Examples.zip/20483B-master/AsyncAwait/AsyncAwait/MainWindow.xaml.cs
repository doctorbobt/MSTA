﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AsyncAwait
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            GetDataAsync();
        }

        // Before C# 5.0 you had to make use of a BackgroundWorker to offload the UI thread.
        // To make async: added async modifier to the method, the name was changed by adding the Async suffix, changed return type from void to Task

        private async Task GetDataAsync() // By returning Task you make the method not only asynchronous, but awaitable as well.
        {
            // approximately equivalent with: Task<double> task = ReadDataFromIOAsync();
            // lblResult.Content = task.Result;

            // lblResult.Content = await ReadDataFromIOAsync();
            // lblResult2.Content = await ReadDataFromIOAsync();
            // Changed to:

            var task1 = ReadDataFromIOAsync();
            var task2 = ReadDataFromIOAsync();

            // Here we can do more processing
            // that doesn't need the data from the previous calls.

            // Now we need the data so we have to wait
            // After you get the data, the calling method gets unblocked.
            await Task.WhenAll(task1, task2);
            

            // Now we have data to show.
            lblResult.Content = task1.Result;
            lblResult2.Content = task2.Result;
        }

        public static double ReadDataFromIO()
        {
            // We are simulating an I/O by putting the current thread to sleep.
            Thread.Sleep(2000);
            return 10d;
        }

        // Instead of directly returning the 10 value, we return a Task that contains it.
        public static Task<double> ReadDataFromIOAsync()
        {
            return Task.Run(new Func<double>(ReadDataFromIO));
        }
    }
}
