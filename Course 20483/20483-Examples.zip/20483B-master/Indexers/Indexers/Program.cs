﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexers
{
    class Program
    {
        static void Main(string[] args)
        {
            IPAddress myIP = new IPAddress();
            // initialize the IP address to all zeros
            for (int i = 0; i < 32; i++)
            {
                myIP[i] = 0;
            }

            myIP[30] = 1;

            for (int i = 0; i < 32; i++)
            {
                Console.WriteLine(myIP[i]);
            }
            Console.ReadKey();
        }
    }

    // Only one indexed property can exist in a single class or struct.
    public class IPAddress
    {
        private int[] ip = new int[32];

        // indexed property to store the 32 bits of an IP address
        public int this[int index] // accepting an index for the value parameter
        {
            get
            {
                return ip[index];
            }
            set
            {
                if (value == 0 || value == 1)
                    ip[index] = value;
                else
                    throw new Exception("Invalid value");
            }
        }
    }
}
