﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BarrierSample
{
    class Program
    {
        static void Main(string[] args)
        {
            var participants = 5;

            CancellationTokenSource tokenSource = new CancellationTokenSource(); // used to signal that the Task should cancel itself.

            Barrier barrier = new Barrier(participants,
            b =>
            { // This method is only called when all the paricipants arrived.
                Console.WriteLine("{0} paricipants are at rendez-vous point {1}.",
                b.ParticipantCount,
                b.CurrentPhaseNumber);
            });
            for (int i = 0; i < participants; i++)
            {
                var localCopy = i;
                Task.Run(() =>
                {
                    Console.WriteLine("Task {0} left point A!", localCopy);
                    Thread.Sleep(1000 * localCopy + 1); // Do some "work"
                    if (localCopy % 2 == 0)
                    {
                        Console.WriteLine("Task {0} arrived at point B!", localCopy);
                        barrier.SignalAndWait(tokenSource.Token); // allows the operation to initiate the cancellation
                    }
                    else
                    {
                        Console.WriteLine("Task {0} changed its mind and went back!", localCopy);
                        barrier.RemoveParticipant();
                        return;
                    }
                    Thread.Sleep(1000 * localCopy); // Do some "more work"
                    Console.WriteLine("Task {0} arrived at point C!", localCopy);
                    barrier.SignalAndWait(tokenSource.Token); // periodically monitors the token to see whether cancellation is requested
                });
            }

            // Back at main thread
            Console.WriteLine("Main thread is waiting for {0} tasks!", barrier.ParticipantCount - 1);


            Console.WriteLine("Press enter to cancel!");
            Console.ReadLine();
            if (barrier.CurrentPhaseNumber < 2) // If this is 2, it means that everyone passed through the first and second phase, so there is no need to cancel the operation.
            {
                tokenSource.Cancel(); // sends cancellation signals to all objects waiting on the barrier object, effectively unblocking them and canceling the remainder of the operation
                Console.WriteLine("We canceled the operation!");
            }
            else
            {
                Console.WriteLine("Too late to cancel!");
            }
            Console.WriteLine("Main thread is done!");
            Console.ReadKey();
        }
    }
}
