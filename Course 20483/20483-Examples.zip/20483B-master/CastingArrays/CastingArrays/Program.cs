﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declare and initialize an array of Employees.
            Employee[] employees = new Employee[10];
            for (int id = 0; id < employees.Length; id++)
                employees[id] = new Employee(id);

            // Implicit cast to an array of Persons.
            // (An Employee is a type of Person, so this cast is valid)
            Person[] persons = employees;

            // Explicit cast back to an array of Employees (narrowing conversion)
            // Because the persons in the array are employees, this cast is valid
            employees = (Employee[])persons;

            // Use the is operator to determine whether the  persons array is compatible with the type Employee[]
            // In this example, persons holds a reference to an array of Employee objects, so it is compatible
            if (persons is Employee[])
            {
                // Treat them as Employees.
            }

            // Use the as operator 
            // Because the persons in the array are employees, this cast is valid
            employees = persons as Employee[];

            // Because persons holds employees, which cannot be converted into managers, this conversion fails (see notes)
            // After this as statement, managers is null.
            Manager[] managers = persons as Manager[];
            
            foreach(Manager manager in managers)
            {
                Console.WriteLine("hoi!");
            }

            // uses the is operator to see if persons can be converted into an array of Managers.
            // Again that conversion won’t work, so the code inside this if block is skipped.
            if (persons is Manager[])
            {
                // Treat them as Managers.
            }
            
            // This cast fails at run time because the array holds Employees not Managers.
            managers = (Manager[])persons;
        }
    }

    class Person
    {
    }
    class Employee : Person // Inheritance!
    {
        public int id;
        public Employee(int id)
        {
            this.id = id;
        }
    }

    class Manager : Employee // Inheritance!
    {
        public Manager(int id) : base(id)
        {
        }
    }
}
