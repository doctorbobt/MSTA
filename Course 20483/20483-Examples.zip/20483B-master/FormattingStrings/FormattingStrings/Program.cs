﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormattingStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            // Displaying a number with a currency format string
            double cost = 1234.56;
            Console.WriteLine(cost.ToString("C", new CultureInfo("en-US")));
            // Displays $1,234.56

            // Displaying a DateTime with different format strings
            DateTime d = new DateTime(2013, 4, 22);
            CultureInfo provider = new CultureInfo("en-US");
            Console.WriteLine(d.ToString("d", provider)); // Displays 4/22/2013
            Console.WriteLine(d.ToString("D", provider)); // Displays Monday, April 22, 2013
            Console.WriteLine(d.ToString("M", provider)); // Displays April 22

            // Show custom formatting on 007
            Person doubleOSeven = new Person("James", "Bond");

            // Display text with string interpolation (usually more readable, so it’s usually preferred)
            Console.WriteLine($"My name's {doubleOSeven.ToString("L")}, {doubleOSeven.ToString("FL")}");

            Console.ReadKey();
        }

        class Person
        {
            public Person(string firstName, string lastName)
            {
                FirstName = firstName;
                LastName = lastName;
            }
            public string FirstName { get; set; }
            public string LastName { get; set; }

            // Implementing custom formatting
            public string ToString(string format)
            {
                if (string.IsNullOrWhiteSpace(format) || format == "G")
                    format = "FL";

                format = format.Trim().ToUpperInvariant();
                switch (format)
                {
                    case "FL":
                        return FirstName + " " + LastName;
                    case "LF":
                        return LastName + " " + FirstName;
                    case "FSL":
                        return FirstName + ", " + LastName;
                    case "LSF":
                        return LastName + ", " + FirstName;
                    case "L":
                        return LastName;
                    default:
                        throw new FormatException(String.Format("The '{ 0 }' format string is not supported.", format));
                }
            }
        }
    }
}
