﻿using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace ConcurrentCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            BlockingCollection<int> bCollection = new BlockingCollection<int>(boundedCapacity: 10);

            Task producerThread = Task.Factory.StartNew(() =>
            {
                for (int i = 0; i < 10; ++i)
                {
                    bCollection.Add(i);
                }

                bCollection.CompleteAdding(); // marks the BlockingCollection instance that it will not add any more items. 
            });

            Task consumerThread = Task.Factory.StartNew(() =>
            {
                while (!bCollection.IsCompleted) // returns true when IsAddingCompleted is true and the BlockingCollection is empty
                {
                    int item = bCollection.Take();
                    Console.WriteLine(item);
                }
            });

            Task.WaitAll(producerThread, consumerThread);
            Console.ReadKey();

            // Alternative: BlockingCollection in the Foreach loop
            // BlockingCollection provides a GetConsumingEnumerable() method. This method returns IEnumerable<T> so that we can use that method in the foreach loop. 
            // This method returns items as soon as item is available in the collection.
            // This method has a blocking feature. It will block the foreach loop when the collection is empty. 
            // A foreach loop ends when the producer thread calls the CompleteAdding method.

            /*foreach (int item in bCollection.GetConsumingEnumerable())
            {
                Console.WriteLine(item);
            }*/

            
        }
    }
}
