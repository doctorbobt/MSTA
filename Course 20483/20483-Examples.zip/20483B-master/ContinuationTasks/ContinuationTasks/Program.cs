﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContinuationTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            // Step1, Step2 and Step3 are independent of each other
            Parallel.Invoke(Step1, Step2, Step3);
            Console.WriteLine("");

            // Step1 and Step2 are independent of each other, and Step3 can be run only after Step1 finishes
            Task step1Task = Task.Run(() => Step1());
            Task step2Task = Task.Run(() => Step2());
            Task step3Task = step1Task.ContinueWith((previousTask) => Step3());
            Task.WaitAll(step2Task, step3Task);
            Console.WriteLine("");

            // Step1 and Step2 are independent of each other, and Step3 can be run only after Step1 and Step2 finish.
            Task step1Task2 = Task.Run(() => Step1());
            Task step2Task2= Task.Run(() => Step2());
            Task step3Task2 = Task.Factory.ContinueWhenAll(
                new Task[] {step1Task2, step2Task2}, 
                (previousTasks) => Step3());

            step3Task2.Wait();
            Console.WriteLine("");

            // Step1 and  Step2 are independent of each other, and Step3 can be run only after Step1 or Step2 finishes.
            Task step1Task3 = Task.Run(() => Step1());
            Task step2Task3 = Task.Run(() => Step2());
            Task step3Task3 = Task.Factory.ContinueWhenAny(
                new Task[] { step1Task3, step2Task3 },
                (previousTask) => Step3());
            step3Task3.Wait();
            Console.ReadKey();
        }
        static void Step1()
        {
            Console.WriteLine("Step1");
        }
        static void Step2()
        {
            Console.WriteLine("Step2");
        }
        static void Step3()
        {
            Console.WriteLine("Step3");
        }
    }
}
