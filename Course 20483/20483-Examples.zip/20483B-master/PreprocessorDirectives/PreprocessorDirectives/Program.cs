﻿#define MySymbol // defines a preprocessor symbol 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreprocessorDirectives
{
    class Program
    {
        static void Main(string[] args)
        {

#line 1337 "Elite method"
            Console.WriteLine("********** " + Environment.StackTrace); // This stack trace would indicate that the Console.WriteLine statement is at line 1337 in the file "Elite method"
            PreprocessorDirectivesTest();
            Console.ReadKey();
        }

#warning This code is obsolete
        private static void PreprocessorDirectivesTest()
        {
#if DEBUG
    Console.WriteLine("Mode=Debug"); 
//#error Debug build is not allowed
#elif MySymbol
            Console.WriteLine("MySymbol is defined!"); 
#else
            Console.WriteLine("Mode=Release"); 
#endif
        }
    }

    class OrderItem
    {
#pragma warning disable 0649 // disables warning number 0649, which is the “never assigned to” warning.
        public string Description;
#pragma warning restore 0649 // re-enables the warning
        public int Quantity = 0;
        public decimal UnitPrice = 0;
    }
}
