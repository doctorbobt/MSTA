﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressions
{
    class Program
    {
        static void Main(string[] args)
        {
            // Expression lambdas
            Action sayHi = () => Console.WriteLine("Hi");
            sayHi += () => Console.WriteLine("Hi again!");

            sayHi();

            Action<string> saySomething = message => Console.WriteLine(message);
            saySomething("Something!");

            Action<string, string> sayTwoThings = (firstThing, secondThing) => Console.WriteLine(firstThing + " " + secondThing);
            sayTwoThings("Two", "things!");

            Func<float, float> square = (float x) => x * x; // returns x * x 
            Console.WriteLine(square(13));

            // Statement lambdas
            Func<float, float> squareStatement = (float x) => { float result = x * x; return result; }; // returns x * x 
            Console.WriteLine(square(13));

            // Async lambdas
            Action asyncLamda = async() =>
            {
                Console.WriteLine("Started the async method...");
                await DoSomethingAsync();
                Console.WriteLine("Done!");
            };

            asyncLamda();

            Console.ReadKey();
        }

        // Do something time consuming.
        // It would normally do something more useful, such as downloading a file from the internet
        async static Task DoSomethingAsync()
        {
            // In this example, just waste some time.
            await Task.Delay(3000);
        }
    }
}
