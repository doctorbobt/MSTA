﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            ExampleClass ec = new ExampleClass();
            // The following call to exampleMethod causes a compiler error 
            //ec.ExampleMethod(10, 4);

            dynamic dynamic_ec = new ExampleClass();

            // The following lines are not identified as an error by the
            // compiler, but it causes a run-time exception.
            dynamic_ec.ExampleMethod(10, 4);
            dynamic_ec.SomeMethod("some argument", 7, null);
            dynamic_ec.NonExistentMethod();
        }

        class ExampleClass
        {
            public void ExampleMethod(int i)
            {
            }
        }
    }
}
