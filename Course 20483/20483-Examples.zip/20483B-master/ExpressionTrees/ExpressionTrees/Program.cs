﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionTrees
{
    class Program
    {
        static void Main(string[] args)
        {

            // Creating “Hello World!” with an expression tree

            // The expression is first constructed with a call to Console.Write and Console.WriteLine
            BlockExpression blockExpr = Expression.Block(
            Expression.Call( 
                null,
                typeof(Console).GetMethod("Write", new Type[] { typeof(String) }),
                Expression.Constant("Hello ")
            ),
            Expression.Call(
                null,
                typeof(Console).GetMethod("WriteLine", new Type[] { typeof(String) }),
                Expression.Constant("World!")
            ),
            Expression.Call(
                typeof(Console).GetMethod("ReadLine"))
            );

            // After construction, the expression is compiled to an Action(because it doesn’t return anything) and executed.
            Expression.Lambda<Action>(blockExpr).Compile()();

        }
    }
}
