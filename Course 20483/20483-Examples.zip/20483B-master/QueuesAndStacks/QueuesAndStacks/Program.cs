﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueuesAndStacks
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<string> myQueue = new Queue<string>();
            myQueue.Enqueue("test"); // adds an element to the end of the Queue
            myQueue.Enqueue("Hello"); // adds an element to the end of the Queue
            myQueue.Enqueue("World"); // adds an element to the end of the Queue
            myQueue.Enqueue("From"); // adds an element to the end of the Queue
            myQueue.Enqueue("A"); // adds an element to the end of the Queue
            myQueue.Enqueue("Queue"); // adds an element to the end of the Queue

            Console.WriteLine(myQueue.Peek()); // returns "test", the oldest element, without removing it 
            Console.WriteLine(myQueue.Dequeue()); // returns "test", the oldest element, and removes it
            // Show the data first-in, first-out (FIFO)
            // Displays: Hello World From A Queue
            foreach (string s in myQueue)
                Console.Write(s + " ");

            Console.WriteLine();

            Stack<string> myStack = new Stack<string>();
            myStack.Push("Hello"); // Add a new item to the Stack
            myStack.Push("World"); // Add a new item to the Stack
            myStack.Push("From"); // Add a new item to the Stack
            myStack.Push("A"); // Add a new item to the Stack
            myStack.Push("Queue"); // Add a new item to the Stack
            myStack.Push("test"); // Add a new item to the Stack

            Console.WriteLine(myStack.Peek()); // returns "test", the oldest element, without removing it 
            Console.WriteLine(myStack.Pop()); // returns "test", the newest element, and removes it

            foreach (string s in myStack)
                Console.Write(s + " ");
            // Displays: Queue A From World Hello

            Console.ReadKey();
        }
    }
}
