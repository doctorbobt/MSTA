﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConcurrentCollections2
{
    class Program
    {
        static void Main(string[] args)
        {
            ConcurrentStack<int> stack = new ConcurrentStack<int>();

            stack.PushRange(new int[] { 1, 2, 3 });

            int[] values = new int[2];

            stack.TryPopRange(values);

            foreach (int i in values)
                Console.WriteLine("In values: " + i);

            foreach (int i in stack)
                Console.WriteLine("In stack: " + i);

            Console.ReadKey();

            // In values: 3
            // In values: 2
            // In stack: 1
        }
    }
}
