﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ManipulateStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            // Changing a character with a StringBuilder
            StringBuilder sb = new StringBuilder("A initial value");
            sb[0] = 'B';

            // Using a StringBuilder in a loop
            StringBuilder sb2 = new StringBuilder(string.Empty);
            for (int i = 0; i < 1000; i++)
            {
                sb2.Append("x");
                sb2.AppendLine(Environment.NewLine); // add blank line between the x'es
            }
            Console.WriteLine(sb2);
            Console.ReadKey();


            // Internally, StringWriter and StringReader use a StringBuilder. The only thing they do is adapt
            // the interface of the StringBuilder to that of the TextWriter and TextReader.
            var stringWriter = new StringWriter();

            // Normally, you pass an instance of StreamWriter so that you can create a new XML file.
            // But when you want the resulting XML only in memory, you can pass a StringWriter
            using (XmlWriter writer = XmlWriter.Create(stringWriter)) // expects an instance of TextWriter
            {
                writer.WriteStartElement("book");
                writer.WriteElementString("price", "19.95");
                writer.WriteEndElement();
                writer.Flush();
            }
            string xml = stringWriter.ToString();

            // Result: <?xml version=\”1.0\” encoding=\”utf-16\”?><book><price> 19.95 </price></book>

            // Using a StringReader as the input for an XmlReader
            var stringReader = new StringReader(xml);
            using (XmlReader reader = XmlReader.Create(stringReader)) // expects an instance of TextWriter
            {
                reader.ReadToFollowing("price");
                decimal price = decimal.Parse(reader.ReadInnerXml(), new CultureInfo("en-US")); // result: 19,95
            }
        }
    }
}
