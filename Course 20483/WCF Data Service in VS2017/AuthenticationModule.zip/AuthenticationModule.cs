﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Data.Entity;
using System.Security.Cryptography;

namespace UtilitiesWcfService
{
    public class BasicAuthenticationModule : IHttpModule
    {
        public void Init(HttpApplication context)
        {
            //Attach handling for authentication requests.
            context.AuthenticateRequest
               += new EventHandler(context_AuthenticateRequest);
        }
        void context_AuthenticateRequest(object sender, EventArgs e)
        {
            //Unbox the application.
            HttpApplication application = (HttpApplication)sender;

            //Send to provider for authentication.
            if (!BasicAuthenticationProvider.Authenticate(application.Context))
            {
                application.Context.Response.Status = "401 Unauthorized";
                application.Context.Response.StatusCode = 401;
                application.Context.Response.AddHeader("WWW-Authenticate", "Basic");
                application.CompleteRequest();
            }
        }
        public void Dispose() { }
    }

    /// <summary>
    /// Provider for basic authentication. Please note that in basic authentication the 
    /// user name and password are delivered in the autentication header therefore
    /// it must be used in an SSL enviorment for this method of authentication to be 
    /// any way secure.
    /// </summary>
    public class BasicAuthenticationProvider
    {
        /// <summary>
        /// Authenticate and the set the current http context user.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static bool Authenticate(HttpContext context)
        {
            //This needs to be uncommented for live site.
            //This will reject the login when not using SSL.
            //if (!HttpContext.Current.Request.IsSecureConnection)
            //    return false;

            //I only want to exceute code for authorization requests.
            if (!HttpContext.Current.Request.Headers.AllKeys.Contains("Authorization"))
                return false;

            string authHeader = HttpContext.Current.Request.Headers["Authorization"];

            IPrincipal principal;
            if (TryGetPrincipal(authHeader, out principal))
            {
                HttpContext.Current.User = principal;
                return true;
            }
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="authHeader"></param>
        /// <param name="principal"></param>
        /// <returns></returns>
        private static bool TryGetPrincipal(string authHeader, out IPrincipal principal)
        {
            var creds = ParseAuthHeader(authHeader);
            if (creds != null && TryGetPrincipal(creds, out principal))
                return true;

            principal = null;
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="creds"></param>
        /// <param name="principal"></param>
        /// <returns></returns>
        private static bool TryGetPrincipal(string[] creds, out IPrincipal principal)
        {
            bool located = false;
            principal = null;

            //The user match.
            var user = new User_SprocResult();

            //The list of roles.
            var roles = new List<Role_SprocResult>();

            //The list of permissions.
            var permissions = new List<Permission_SprocResult>();     

            //Use the entity context.
            using (var dbContext = new AuthenticationEntities())
            {
                //Get first enumerate result set.
                var result = dbContext.aspnet_GetUserCredentials("Utilities", creds[0]);
                user = result.FirstOrDefault();

                //Get second result set
                var result2 = result.GetNextResult<Role_SprocResult>();
                roles.AddRange(result2);

                //Get third result set
                permissions.AddRange(result2.GetNextResult<Permission_SprocResult>());
            }

            //If there are any user matches.
            if (user != null)
            {
                //Get the hash of this users password using the salt provided.
                byte[] bytes = Encoding.Unicode.GetBytes(creds[1]);
                byte[] src = Convert.FromBase64String(user.PasswordSalt);
                byte[] dst = new byte[src.Length + bytes.Length];
                Buffer.BlockCopy(src, 0, dst, 0, src.Length);
                Buffer.BlockCopy(bytes, 0, dst, src.Length, bytes.Length);
                HashAlgorithm algorithm = HashAlgorithm.Create("SHA1");
                byte[] inArray = algorithm.ComputeHash(dst);

                //If the resulting hash is equal to the stored hash for this user.
                if (string.Compare(Convert.ToBase64String(inArray), user.Password) == 0)
                {
                    //Tag as located.
                    located = true;

                    //Set new principal.
                    principal = new CustomPrincipal(user.UserName,
                        roles.Select(r=>r.RoleName).ToArray(),
                        permissions.Select(r=>r.PermissionId).ToArray());
                }
            }

            //Return result.
            return located;
        }

        /// <summary>
        /// In basic authentication the user name and password are in the auth header in base64 encoding.
        /// </summary>
        /// <param name="authHeader"></param>
        /// <returns>The array of credentials i.e. the username and password.</returns>
        private static string[] ParseAuthHeader(string authHeader)
        {
            // Check this is a Basic Auth header 
            if (
                authHeader == null ||
                authHeader.Length == 0 ||
                !authHeader.StartsWith("Basic")
            ) return null;

            // Pull out the Credentials with are seperated by ':' and Base64 encoded 
            string base64Credentials = authHeader.Substring(6);
            string[] credentials = Encoding.ASCII.GetString(
                  Convert.FromBase64String(base64Credentials)
            ).Split(new char[] { ':' });

            if (credentials.Length != 2 ||
                string.IsNullOrEmpty(credentials[0]) ||
                string.IsNullOrEmpty(credentials[0])
            ) return null;

            // Okay this is the credentials 
            return credentials;
        }


        public class CustomPrincipal : IPrincipal
        {
            string[] _roles;
            string[] _permissions;
            IIdentity _identity;

            public CustomPrincipal(string name, string[] roles, string[] permissions)
            {
                this._roles = roles;
                this._permissions = permissions;
                this._identity = new GenericIdentity(name);
            }

            public IIdentity Identity
            {
                get { return _identity; }
            }

            public bool IsInRole(string role)
            {
                return _roles.Contains(role);
            }

            public bool HasPermission(string permission)
            {
                return _permissions.Contains(permission);
            }
        }

        //public class CustomIdentity : IIdentity
        //{
        //    string _name;

        //    public CustomIdentity(string name)
        //    {
        //        this._name = name;
        //    }

        //    string IIdentity.AuthenticationType
        //    {
        //        get { return "Custom SCHEME"; }
        //    }

        //    bool IIdentity.IsAuthenticated
        //    {
        //        get { return true; }
        //    }

        //    string IIdentity.Name
        //    {
        //        get { return _name; }
        //    }
        //}
    }
}