﻿using Microsoft.Azure.ActiveDirectory.GraphClient;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace MenuWcfService
{
    /// <summary>
    /// This class is an IHttpModule is used to check the access token on every incoming request to the site.
    /// </summary>
    public class OAuthProtectionModule : IHttpModule
    {
        /// <summary>
        /// This method is used to do all the initialization for this class.
        /// </summary>
        /// <param name="context">The <see cref="HttpApplication"/> object which contains this module.</param>
        public void Init(HttpApplication context)
        {
            context.AuthenticateRequest += OnAuthenticateRequest;
        }

        /// <summary>
        /// Handle the HTTP pipeline AuthenticateRequest event, after ensuring that the module has been initialized.
        /// </summary>       
        /// <param name="sender">Sender of this event.</param>
        /// <param name="args">Event arguments.</param>
        void OnAuthenticateRequest(object sender, EventArgs args)
        {
            //Unbox the application.
            HttpApplication application = (HttpApplication)sender;

            //Send to provider for authentication.
            if (!OAuthAuthenticationProvider.Authenticate(
                out int statusCode, 
                out string httpStatus, 
                out string wwwAuthenticateResponse))
            {
                //Set the status and status code.
                application.Context.Response.Status = httpStatus;
                application.Context.Response.StatusCode = statusCode;

                //If there is a WWW-Authenticate payload.
                if (!String.IsNullOrEmpty(wwwAuthenticateResponse))
                {
                    //Add the Authenticate header.
                    application.Context.Response.AddHeader("WWW-Authenticate", wwwAuthenticateResponse);
                }
                application.CompleteRequest();
            }
        }

        public void Dispose() { }
    }

    public static class OAuthAuthenticationProvider
    {
        #region Fields

        /// <summary>
        /// The name of the azure AD tenant.
        /// </summary>
        static string tenant = "%YourTenantName%";

        /// <summary>
        /// The signin authority.
        /// </summary>
        static string authority = $"https://login.microsoftonline.com/{tenant}";

        /// <summary>
        /// OpenIdConnect configuration.
        /// </summary>
        static ConfigurationManager<OpenIdConnectConfiguration> configurationManager =
            new ConfigurationManager<OpenIdConnectConfiguration>($"{authority}/.well-known/openid-configuration",
                new OpenIdConnectConfigurationRetriever());

        /// <summary>
        /// MSAL client for graph API lookups.
        /// </summary>
        static ConfidentialClientApplication msaClient;

        /// <summary> 
        /// The application id of the web app and the app id url.
        /// </summary>
       static string[] audiences = { "%DataService Application ID%", "%DataService Sign-On URL%" };

        /// <summary>
        /// The password from App Registrations – App Name – Settings – Keys
        /// </summary>
        static string clientSecret = "%Secret Key%";

        /// <summary>
        /// 
        /// </summary>
        static string scopeClaimType = "http://schemas.microsoft.com/identity/claims/scope";

        /// <summary>
        /// The standard www-authenticate response header.
        /// </summary>
        static string wwwAuthenticate = $"Bearer realm=\"{audiences[1]}\", authorization_uri=\"{authority}\", resource_id=\"{audiences[1]}\"";

        #endregion

        /// <summary>
        /// Authenticate and the set the current http context user.
        /// </summary>
        /// <param name="context">The http context.</param>
        /// <returns>True if the user has been authenticated.</returns>
        public static bool Authenticate(out int statusCode, out string httpStatus, out string wwwAuthenticateResponse)
        {
            //Set inital result.
            bool result = false;

            //If no authorization was provided.
            if (!HttpContext.Current.Request.Headers.AllKeys.Contains("Authorization"))
            {
                httpStatus = "401 Unauthorized";
                statusCode = (int)HttpStatusCode.Unauthorized;
                wwwAuthenticateResponse = wwwAuthenticate;
            }
            //Try to resolve the claims principle.
            else if (TryGetPrincipal(HttpContext.Current.Request.Headers["Authorization"].Substring(7), 
                out IPrincipal principal, 
                out statusCode, 
                out httpStatus, 
                out wwwAuthenticateResponse))
            {
                //Set the claims principle.
                HttpContext.Current.User = principal;
                Thread.CurrentPrincipal = principal;
                result = true;
            }

            //Return the result.
            return result;
        }

        /// <summary>
        /// This method parses the incoming token and validates it.
        /// </summary>
        /// <param name="accessToken">The incoming access token.</param>
        /// <param name="error">This out paramter is set if any error occurs.</param>
        /// <returns>True on success, False on error.</returns>
        static bool TryGetPrincipal(string accessToken, out IPrincipal principal, out int statusCode, out string httpStatus, out string wwwAuthenticateResponse)
        {
            bool overallResult = false;
            principal = null;
            statusCode = 0;
            httpStatus = null;
            wwwAuthenticateResponse = null;

#if DEBUG
            //Show token in execeptions.
            IdentityModelEventSource.ShowPII = true;
#endif
            try
            {
                //Retrieve the configuration for the tennent.
                OpenIdConnectConfiguration config = GetConfigurationNonAsync();

                // validate the token
                var claimsPrincipal = new JwtSecurityTokenHandler().ValidateToken(accessToken,
                      new TokenValidationParameters
                      {
                          ValidateAudience = false,
                          ValidIssuer = config.Issuer,
                          IssuerSigningKeys = config.SigningKeys
                      }
                      , out SecurityToken validatedToken); ;

                // If the token is scoped, verify that required permission is set in the scope claim.
                if (claimsPrincipal.FindFirst(scopeClaimType) != null &&
                    claimsPrincipal.FindFirst(scopeClaimType).Value != "user_impersonation")
                {
                    statusCode = (int)HttpStatusCode.Forbidden;
                    httpStatus = "403 Forbidden";
                    wwwAuthenticateResponse = wwwAuthenticate;
                }
                else
                {
                    //Update the claims principle with the group names.
                    AddGroupNameClaim(claimsPrincipal);

                    //Set out parameter.
                    principal = claimsPrincipal;

                    //Indicate overall success.
                    overallResult = true;
                }
            }            
            catch (SecurityTokenException ex)
            {
                //TO DO: (possibly add exception item to httpcontext or set httpcontext.current.response)
                statusCode = (int)HttpStatusCode.Unauthorized;
                httpStatus = "401 Unauthorized";
                wwwAuthenticateResponse = wwwAuthenticate + $" error=\"invalid_token\", error_description=\"{ex.Message}\"";
            }
            catch (Exception)
            {
                statusCode = (int)HttpStatusCode.InternalServerError;
                httpStatus = "500 InternalServerError";
            }

            //Return result.
            return overallResult;
        }

        static string BuildWWWAuthenticateResponseHeader()
        {
            return $"Bearer authorization_uri =\"{authority}\", resource_id=\"{audiences[0]}";
        }

        /// <summary>
        /// Updates the claims principle with the group name claim.
        /// </summary>
        /// <param name="claimsPrincipal">The claims principle to update.</param>
        public static void AddGroupNameClaim(ClaimsPrincipal claimsPrincipal)
        {
            (claimsPrincipal.Identity as ClaimsIdentity).AddClaims(
                claimsPrincipal.FindAll("groups").Select(r => 
                new Claim("group_name", GetGroupNameByObjectId(r.Value))));
        }

        /// <summary>
        /// Gets the group name for the specified object id.
        /// </summary>
        /// <param name="objectId">The guid for the group.</param>
        public static string GetGroupNameByObjectId(string objectId)
        {
            //Initialize graph client.
            ActiveDirectoryClient activeDirectoryClient = new ActiveDirectoryClient(new Uri($"https://graph.windows.net/{tenant}"), async () =>
            {
                return await Task.Run(async () =>
                {
                    //If the msal client does not exist.
                    if (msaClient == null)
                    {
                        //Initialize the msal client.
                        msaClient = new ConfidentialClientApplication(
                            audiences[0],
                            authority,
                            audiences[1],
                            new Microsoft.Identity.Client.ClientCredential(clientSecret),
                            new Microsoft.Identity.Client.TokenCache(),
                            new Microsoft.Identity.Client.TokenCache());
                    }

                    //Get the token.
                    var authResult = await msaClient.AcquireTokenForClientAsync(new string[] { "https://graph.windows.net/.default" });
                    return authResult.AccessToken;
                });
            });

            IGroup group = null;
            Task.Run(async () =>
            {
                //Get the group object.
                group = await activeDirectoryClient.Groups.GetByObjectId(objectId).ExecuteAsync();
            }).Wait();

            //Return the group name.
            return group?.DisplayName;
        }

        /// <summary>
        /// Retrieve configuration information used to validate the access token.
        /// </summary>
        static OpenIdConnectConfiguration GetConfigurationNonAsync()
        {
            //Get the configuration.
            OpenIdConnectConfiguration config = null;
            Task.Run(async () =>
            {
                // Get Config from AAD:
                config = await configurationManager.GetConfigurationAsync();
            }).Wait();

            //Return the configuration.
            return config;
        }
    }
}